require("dotenv").config();

const express = require("express");
const cors = require("cors");

const app = express();
const PORT = Number(process.env.PORT || 8080);
const ORIGIN = process.env.FRONTEND_ORIGIN || "*";
const MODE = (process.env.DATA_MODE || "demo").toLowerCase();
const CACHE_TTL = Number(process.env.CACHE_TTL_MS || 120000);

app.use(cors({
  origin: ORIGIN === "*" ? true : ORIGIN.split(",").map(x => x.trim()),
  methods: ["GET", "OPTIONS"],
  allowedHeaders: ["Content-Type", "Accept"]
}));
app.use(express.json({ limit: "1mb" }));

const cache = new Map();

const STORE_DOMAINS = {
  amazon: "amazon.in",
  flipkart: "flipkart.com",
  croma: "croma.com",
  reliance: "reliancedigital.in",
  vijaysales: "vijaysales.com",
  tatacliq: "tatacliq.com",
  nykaa: "nykaa.com",
  myntra: "myntra.com",
  purplle: "purplle.com",
  ajio: "ajio.com",
  pepperfry: "pepperfry.com",
  ikea: "ikea.com",
  decathlon: "decathlon.in",
  firstcry: "firstcry.com",
  bigbasket: "bigbasket.com",
  tata1mg: "1mg.com",
  pharmeasy: "pharmeasy.in",
  supertails: "supertails.com",
  headsupfortails: "headsupfortails.com"
};

function normalizeStore(value = "") {
  const s = String(value).toLowerCase();
  if (s.includes("amazon")) return "Amazon";
  if (s.includes("flipkart")) return "Flipkart";
  if (s.includes("croma")) return "Croma";
  if (s.includes("reliance")) return "Reliance Digital";
  if (s.includes("vijay")) return "Vijay Sales";
  if (s.includes("nykaa")) return "Nykaa";
  if (s.includes("myntra")) return "Myntra";
  if (s.includes("purplle")) return "Purplle";
  if (s.includes("ajio")) return "AJIO";
  if (s.includes("tata cliq") || s.includes("tatacliq")) return "Tata CLiQ";
  if (s.includes("decathlon")) return "Decathlon";
  if (s.includes("ikea")) return "IKEA";
  if (s.includes("pepperfry")) return "Pepperfry";
  if (s.includes("firstcry")) return "FirstCry";
  if (s.includes("bigbasket")) return "BigBasket";
  if (s.includes("1mg") || s.includes("tata 1mg")) return "Tata 1mg";
  if (s.includes("pharmeasy")) return "PharmEasy";
  if (s.includes("supertails")) return "Supertails";
  if (s.includes("heads up for tails")) return "Heads Up For Tails";
  return value || "Store";
}

function normalizeOffer(raw, index = 0) {
  const price = Number(raw.price ?? raw.extracted_price ?? raw.current_price ?? NaN);
  const mrp = Number(raw.mrp ?? raw.original_price ?? raw.old_price ?? NaN);
  const safePrice = Number.isFinite(price) ? price : null;
  const safeMrp = Number.isFinite(mrp) ? mrp : null;
  const discount = safePrice && safeMrp && safeMrp > safePrice
    ? Math.round((safeMrp - safePrice) / safeMrp * 100)
    : (raw.discount != null ? Number(raw.discount) : null);

  const title = raw.title || raw.name || "Unknown product";
  const store = normalizeStore(raw.source || raw.store || raw.merchant || raw.seller || raw.domain);

  return {
    id: String(raw.product_id || raw.id || `${store}-${index}-${title}`).slice(0, 180),
    title,
    brand: raw.brand || null,
    price: safePrice,
    mrp: safeMrp,
    discount: Number.isFinite(discount) ? discount : null,
    rating: raw.rating != null ? Number(raw.rating) : null,
    reviews: raw.reviews != null ? Number(raw.reviews) : null,
    inStock: raw.in_stock ?? raw.inStock ?? true,
    availText: raw.availability || raw.availText || null,
    store,
    delivery: raw.delivery || null,
    image: raw.thumbnail || raw.image || raw.image_url || null,
    url: raw.link || raw.url || null,
    currency: raw.currency || "INR",
    specs: Array.isArray(raw.specs) ? raw.specs.slice(0, 8) : []
  };
}

function demoOffers(q, category) {
  const lower = q.toLowerCase();
  const isBeauty = category === "beauty" || /serum|sunscreen|lipstick|shampoo|moisturizer|face wash|foundation|makeup/.test(lower);
  const base = isBeauty
    ? [
        ["Nykaa", 699, 999, "https://www.nykaa.com/"],
        ["Amazon", 649, 999, "https://www.amazon.in/"],
        ["Flipkart", 679, 999, "https://www.flipkart.com/"],
        ["Myntra", 729, 999, "https://www.myntra.com/"],
        ["Purplle", 629, 999, "https://www.purplle.com/"]
      ]
    : [
        ["Amazon", 74999, 89999, "https://www.amazon.in/"],
        ["Flipkart", 73999, 89999, "https://www.flipkart.com/"],
        ["Croma", 75990, 89999, "https://www.croma.com/"],
        ["Reliance Digital", 76999, 89999, "https://www.reliancedigital.in/"],
        ["Vijay Sales", 75499, 89999, "https://www.vijaysales.com/"]
      ];

  return base.map(([store, price, mrp, url], i) => normalizeOffer({
    id: `demo-${i}`,
    title: q,
    brand: isBeauty ? "Demo Beauty" : "Demo Brand",
    price,
    mrp,
    discount: Math.round((mrp - price) / mrp * 100),
    rating: 4.1 + (i % 4) * 0.2,
    reviews: 120 + i * 91,
    in_stock: true,
    availability: "Available",
    store,
    delivery: "Delivery available",
    link: url,
    specs: isBeauty ? ["India", "Original product", "Multiple variants"] : ["Warranty", "India", "Multiple variants"]
  }, i));
}

async function serpApiSearch(q, category) {
  const key = process.env.SERPAPI_KEY;
  if (!key) return null;

  const params = new URLSearchParams({
    engine: process.env.SERPAPI_ENGINE || "google_shopping",
    q,
    api_key: key,
    gl: process.env.COUNTRY || "in",
    hl: process.env.LANGUAGE || "en",
    currency: process.env.CURRENCY || "INR"
  });

  const response = await fetch(`https://serpapi.com/search.json?${params}`);
  if (!response.ok) throw new Error(`Shopping provider HTTP ${response.status}`);

  const data = await response.json();
  const products = Array.isArray(data.shopping_results) ? data.shopping_results : [];
  return products.map((p, i) => normalizeOffer({
    ...p,
    source: p.source || p.merchant
  }, i));
}

async function searchOffers(q, category) {
  const key = `${category}|${q.trim().toLowerCase()}`;
  const cached = cache.get(key);
  if (cached && Date.now() - cached.time < CACHE_TTL) return cached.data;

  let offers = null;

  if (MODE === "live" || process.env.SERPAPI_KEY) {
    offers = await serpApiSearch(q, category);
  }

  if (!offers || !offers.length) {
    offers = demoOffers(q, category);
  }

  cache.set(key, { time: Date.now(), data: offers });
  return offers;
}

app.get("/api/health", (req, res) => {
  res.json({
    ok: true,
    service: "ShopSmart AI API",
    mode: MODE,
    liveProvider: Boolean(process.env.SERPAPI_KEY),
    time: new Date().toISOString()
  });
});

app.get("/api/search", async (req, res) => {
  try {
    const q = String(req.query.q || req.query.query || "").trim();
    const category = String(req.query.category || "electronics").trim().toLowerCase();

    if (!q) {
      return res.status(400).json({ error: "Missing q parameter", offers: [] });
    }
    if (q.length > 160) {
      return res.status(400).json({ error: "Query is too long", offers: [] });
    }

    const offers = await searchOffers(q, category);

    res.set("Cache-Control", "no-store");
    res.json({
      query: q,
      category,
      currency: "INR",
      updatedAt: new Date().toISOString(),
      count: offers.length,
      offers
    });
  } catch (err) {
    console.error(err);
    res.status(502).json({
      error: "Price provider unavailable",
      message: err.message,
      offers: []
    });
  }
});

app.get("/api/stores", (req, res) => {
  res.json({
    stores: Object.entries(STORE_DOMAINS).map(([id, domain]) => ({ id, domain }))
  });
});

app.get("/", (req, res) => {
  res.json({
    name: "ShopSmart AI API",
    status: "running",
    endpoints: [
      "GET /api/health",
      "GET /api/search?q=iPhone%2016%20Pro&category=electronics",
      "GET /api/stores"
    ]
  });
});

app.use((req, res) => {
  res.status(404).json({ error: "Route not found" });
});

app.listen(PORT, () => {
  console.log(`ShopSmart AI API listening on port ${PORT}`);
});
